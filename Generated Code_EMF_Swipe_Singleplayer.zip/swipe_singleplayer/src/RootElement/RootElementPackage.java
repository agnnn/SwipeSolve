/**
 */
package RootElement;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see RootElement.RootElementFactory
 * @model kind="package"
 * @generated
 */
public interface RootElementPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "RootElement";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///RootElement.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "RootElement";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RootElementPackage eINSTANCE = RootElement.impl.RootElementPackageImpl.init();

	/**
	 * The meta object id for the '{@link RootElement.impl.PersonImpl <em>Person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.PersonImpl
	 * @see RootElement.impl.RootElementPackageImpl#getPerson()
	 * @generated
	 */
	int PERSON = 0;

	/**
	 * The feature id for the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__PASSWORD = 0;

	/**
	 * The feature id for the '<em><b>Highscore</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__HIGHSCORE = 1;

	/**
	 * The feature id for the '<em><b>Logged In</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__LOGGED_IN = 2;

	/**
	 * The feature id for the '<em><b>Serial Verison UID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__SERIAL_VERISON_UID = 3;

	/**
	 * The feature id for the '<em><b>Username</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__USERNAME = 4;

	/**
	 * The feature id for the '<em><b>Person</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__PERSON = 5;

	/**
	 * The number of structural features of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Constraintpass</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___CONSTRAINTPASS__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 1;

	/**
	 * The operation id for the '<em>Constraint2</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___CONSTRAINT2__DIAGNOSTICCHAIN_MAP = 2;

	/**
	 * The operation id for the '<em>Constraint3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___CONSTRAINT3__DIAGNOSTICCHAIN_MAP = 3;

	/**
	 * The operation id for the '<em>Register Person</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___REGISTER_PERSON__PERSON = 4;

	/**
	 * The operation id for the '<em>Confirm Login</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___CONFIRM_LOGIN__PERSON = 5;

	/**
	 * The operation id for the '<em>Get Total High Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___GET_TOTAL_HIGH_SCORE = 6;

	/**
	 * The operation id for the '<em>Set Total High Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___SET_TOTAL_HIGH_SCORE__PERSON_INT = 7;

	/**
	 * The operation id for the '<em>Compare To</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___COMPARE_TO__PERSON = 8;

	/**
	 * The operation id for the '<em>Read Person</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___READ_PERSON = 9;

	/**
	 * The operation id for the '<em>Write Person</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___WRITE_PERSON__PERSON = 10;

	/**
	 * The operation id for the '<em>Person</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON___PERSON__STRING_STRING = 11;

	/**
	 * The number of operations of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_OPERATION_COUNT = 12;

	/**
	 * The meta object id for the '{@link RootElement.impl.PieceImpl <em>Piece</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.PieceImpl
	 * @see RootElement.impl.RootElementPackageImpl#getPiece()
	 * @generated
	 */
	int PIECE = 2;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE__X = 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE__Y = 1;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE__WIDTH = 2;

	/**
	 * The feature id for the '<em><b>Rectangle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE__RECTANGLE = 3;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE__HEIGHT = 4;

	/**
	 * The number of structural features of the '<em>Piece</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Piece</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIECE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.impl.basketImpl <em>basket</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.basketImpl
	 * @see RootElement.impl.RootElementPackageImpl#getbasket()
	 * @generated
	 */
	int BASKET = 1;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET__X = PIECE__X;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET__Y = PIECE__Y;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET__WIDTH = PIECE__WIDTH;

	/**
	 * The feature id for the '<em><b>Rectangle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET__RECTANGLE = PIECE__RECTANGLE;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET__HEIGHT = PIECE__HEIGHT;

	/**
	 * The feature id for the '<em><b>Game</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET__GAME = PIECE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>basket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET_FEATURE_COUNT = PIECE_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Basket</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET___BASKET__INT_INT_INT_INT = PIECE_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>basket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASKET_OPERATION_COUNT = PIECE_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link RootElement.impl.GamePanelImpl <em>Game Panel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.GamePanelImpl
	 * @see RootElement.impl.RootElementPackageImpl#getGamePanel()
	 * @generated
	 */
	int GAME_PANEL = 3;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__TIME = 0;

	/**
	 * The feature id for the '<em><b>Basket X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__BASKET_X = 1;

	/**
	 * The feature id for the '<em><b>Reverse</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__REVERSE = 2;

	/**
	 * The feature id for the '<em><b>Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__START = 3;

	/**
	 * The feature id for the '<em><b>End</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__END = 4;

	/**
	 * The feature id for the '<em><b>Pause Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__PAUSE_START = 5;

	/**
	 * The feature id for the '<em><b>Temp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__TEMP = 6;

	/**
	 * The feature id for the '<em><b>Basket</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL__BASKET = 7;

	/**
	 * The number of structural features of the '<em>Game Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL_FEATURE_COUNT = 8;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Constraint2</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___CONSTRAINT2__DIAGNOSTICCHAIN_MAP = 1;

	/**
	 * The operation id for the '<em>Constraint3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___CONSTRAINT3__DIAGNOSTICCHAIN_MAP = 2;

	/**
	 * The operation id for the '<em>Gamepanel</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___GAMEPANEL__INT = 3;

	/**
	 * The operation id for the '<em>Pause Game</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___PAUSE_GAME = 4;

	/**
	 * The operation id for the '<em>Resume Game</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___RESUME_GAME = 5;

	/**
	 * The operation id for the '<em>Paint Component</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___PAINT_COMPONENT = 6;

	/**
	 * The operation id for the '<em>Operation5</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___OPERATION5 = 7;

	/**
	 * The operation id for the '<em>Operation6</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___OPERATION6 = 8;

	/**
	 * The operation id for the '<em>Operation7</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL___OPERATION7 = 9;

	/**
	 * The number of operations of the '<em>Game Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_PANEL_OPERATION_COUNT = 10;

	/**
	 * The meta object id for the '{@link RootElement.impl.BallImpl <em>Ball</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.BallImpl
	 * @see RootElement.impl.RootElementPackageImpl#getBall()
	 * @generated
	 */
	int BALL = 4;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL__X = PIECE__X;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL__Y = PIECE__Y;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL__WIDTH = PIECE__WIDTH;

	/**
	 * The feature id for the '<em><b>Rectangle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL__RECTANGLE = PIECE__RECTANGLE;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL__HEIGHT = PIECE__HEIGHT;

	/**
	 * The number of structural features of the '<em>Ball</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL_FEATURE_COUNT = PIECE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Ball</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL___BALL__INT_INT_INT_INT = PIECE_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Ball</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BALL_OPERATION_COUNT = PIECE_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link RootElement.impl.MainImpl <em>Main</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.MainImpl
	 * @see RootElement.impl.RootElementPackageImpl#getMain()
	 * @generated
	 */
	int MAIN = 5;

	/**
	 * The number of structural features of the '<em>Main</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Main</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN___MAIN = 0;

	/**
	 * The number of operations of the '<em>Main</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link RootElement.impl.DashBoardImpl <em>Dash Board</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.DashBoardImpl
	 * @see RootElement.impl.RootElementPackageImpl#getDashBoard()
	 * @generated
	 */
	int DASH_BOARD = 6;

	/**
	 * The number of structural features of the '<em>Dash Board</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASH_BOARD_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Dashboard</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASH_BOARD___DASHBOARD = 0;

	/**
	 * The number of operations of the '<em>Dash Board</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASH_BOARD_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link RootElement.impl.GameImpl <em>Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.GameImpl
	 * @see RootElement.impl.RootElementPackageImpl#getGame()
	 * @generated
	 */
	int GAME = 7;

	/**
	 * The feature id for the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__SCORE = 0;

	/**
	 * The feature id for the '<em><b>Color Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__COLOR_INDEX = 1;

	/**
	 * The feature id for the '<em><b>Colors</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__COLORS = 2;

	/**
	 * The number of structural features of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Get Instance</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___GET_INSTANCE__INT_INT = 0;

	/**
	 * The operation id for the '<em>Get New Instance</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___GET_NEW_INSTANCE__INT_INT = 1;

	/**
	 * The operation id for the '<em>Game</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___GAME__INT_INT = 2;

	/**
	 * The operation id for the '<em>Get Frame</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___GET_FRAME = 3;

	/**
	 * The operation id for the '<em>Reset Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___RESET_SCORE = 4;

	/**
	 * The operation id for the '<em>Set Score</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___SET_SCORE__BOOLEAN = 5;

	/**
	 * The operation id for the '<em>Set Time</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME___SET_TIME__INT = 6;

	/**
	 * The number of operations of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OPERATION_COUNT = 7;

	/**
	 * The meta object id for the '{@link RootElement.impl.GameEndingImpl <em>Game Ending</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.GameEndingImpl
	 * @see RootElement.impl.RootElementPackageImpl#getGameEnding()
	 * @generated
	 */
	int GAME_ENDING = 8;

	/**
	 * The number of structural features of the '<em>Game Ending</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_ENDING_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Game Ending</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_ENDING___GAME_ENDING = 0;

	/**
	 * The number of operations of the '<em>Game Ending</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_ENDING_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link RootElement.impl.SelectionImpl <em>Selection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.SelectionImpl
	 * @see RootElement.impl.RootElementPackageImpl#getSelection()
	 * @generated
	 */
	int SELECTION = 9;

	/**
	 * The feature id for the '<em><b>Selected</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION__SELECTED = 0;

	/**
	 * The number of structural features of the '<em>Selection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Constraint1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Selection</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION___SELECTION = 1;

	/**
	 * The number of operations of the '<em>Selection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link RootElement.impl.personsImpl <em>persons</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.personsImpl
	 * @see RootElement.impl.RootElementPackageImpl#getpersons()
	 * @generated
	 */
	int PERSONS = 10;

	/**
	 * The number of structural features of the '<em>persons</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSONS_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>persons</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSONS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.impl.StateMachine1Impl <em>State Machine1</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.StateMachine1Impl
	 * @see RootElement.impl.RootElementPackageImpl#getStateMachine1()
	 * @generated
	 */
	int STATE_MACHINE1 = 11;

	/**
	 * The number of structural features of the '<em>State Machine1</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE1_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>State Machine1</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE1_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.impl.StateMachine2Impl <em>State Machine2</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.impl.StateMachine2Impl
	 * @see RootElement.impl.RootElementPackageImpl#getStateMachine2()
	 * @generated
	 */
	int STATE_MACHINE2 = 12;

	/**
	 * The number of structural features of the '<em>State Machine2</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE2_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>State Machine2</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE2_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link RootElement.Person <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Person</em>'.
	 * @see RootElement.Person
	 * @generated
	 */
	EClass getPerson();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Person#getPassword <em>Password</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Password</em>'.
	 * @see RootElement.Person#getPassword()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Password();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Person#getHighscore <em>Highscore</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Highscore</em>'.
	 * @see RootElement.Person#getHighscore()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Highscore();

	/**
	 * Returns the meta object for the reference '{@link RootElement.Person#getLoggedIn <em>Logged In</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Logged In</em>'.
	 * @see RootElement.Person#getLoggedIn()
	 * @see #getPerson()
	 * @generated
	 */
	EReference getPerson_LoggedIn();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Person#getSerialVerisonUID <em>Serial Verison UID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Serial Verison UID</em>'.
	 * @see RootElement.Person#getSerialVerisonUID()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_SerialVerisonUID();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Person#getUsername <em>Username</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Username</em>'.
	 * @see RootElement.Person#getUsername()
	 * @see #getPerson()
	 * @generated
	 */
	EAttribute getPerson_Username();

	/**
	 * Returns the meta object for the reference '{@link RootElement.Person#getPerson <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Person</em>'.
	 * @see RootElement.Person#getPerson()
	 * @see #getPerson()
	 * @generated
	 */
	EReference getPerson_Person();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#Constraintpass(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraintpass</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraintpass</em>' operation.
	 * @see RootElement.Person#Constraintpass(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getPerson__Constraintpass__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#Constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see RootElement.Person#Constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getPerson__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#Constraint2(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint2</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint2</em>' operation.
	 * @see RootElement.Person#Constraint2(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getPerson__Constraint2__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#Constraint3(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint3</em>' operation.
	 * @see RootElement.Person#Constraint3(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getPerson__Constraint3__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#registerPerson(RootElement.Person) <em>Register Person</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Person</em>' operation.
	 * @see RootElement.Person#registerPerson(RootElement.Person)
	 * @generated
	 */
	EOperation getPerson__RegisterPerson__Person();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#confirmLogin(RootElement.Person) <em>Confirm Login</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Confirm Login</em>' operation.
	 * @see RootElement.Person#confirmLogin(RootElement.Person)
	 * @generated
	 */
	EOperation getPerson__ConfirmLogin__Person();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#getTotalHighScore() <em>Get Total High Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Total High Score</em>' operation.
	 * @see RootElement.Person#getTotalHighScore()
	 * @generated
	 */
	EOperation getPerson__GetTotalHighScore();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#setTotalHighScore(RootElement.Person, int) <em>Set Total High Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Total High Score</em>' operation.
	 * @see RootElement.Person#setTotalHighScore(RootElement.Person, int)
	 * @generated
	 */
	EOperation getPerson__SetTotalHighScore__Person_int();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#compareTo(RootElement.Person) <em>Compare To</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Compare To</em>' operation.
	 * @see RootElement.Person#compareTo(RootElement.Person)
	 * @generated
	 */
	EOperation getPerson__CompareTo__Person();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#readPerson() <em>Read Person</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Read Person</em>' operation.
	 * @see RootElement.Person#readPerson()
	 * @generated
	 */
	EOperation getPerson__ReadPerson();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#writePerson(RootElement.Person) <em>Write Person</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Write Person</em>' operation.
	 * @see RootElement.Person#writePerson(RootElement.Person)
	 * @generated
	 */
	EOperation getPerson__WritePerson__Person();

	/**
	 * Returns the meta object for the '{@link RootElement.Person#Person(java.lang.String, java.lang.String) <em>Person</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Person</em>' operation.
	 * @see RootElement.Person#Person(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getPerson__Person__String_String();

	/**
	 * Returns the meta object for class '{@link RootElement.basket <em>basket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>basket</em>'.
	 * @see RootElement.basket
	 * @generated
	 */
	EClass getbasket();

	/**
	 * Returns the meta object for the reference '{@link RootElement.basket#getGame <em>Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Game</em>'.
	 * @see RootElement.basket#getGame()
	 * @see #getbasket()
	 * @generated
	 */
	EReference getbasket_Game();

	/**
	 * Returns the meta object for the '{@link RootElement.basket#Basket(int, int, int, int) <em>Basket</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Basket</em>' operation.
	 * @see RootElement.basket#Basket(int, int, int, int)
	 * @generated
	 */
	EOperation getbasket__Basket__int_int_int_int();

	/**
	 * Returns the meta object for class '{@link RootElement.Piece <em>Piece</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Piece</em>'.
	 * @see RootElement.Piece
	 * @generated
	 */
	EClass getPiece();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Piece#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see RootElement.Piece#getX()
	 * @see #getPiece()
	 * @generated
	 */
	EAttribute getPiece_X();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Piece#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see RootElement.Piece#getY()
	 * @see #getPiece()
	 * @generated
	 */
	EAttribute getPiece_Y();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Piece#getWidth <em>Width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Width</em>'.
	 * @see RootElement.Piece#getWidth()
	 * @see #getPiece()
	 * @generated
	 */
	EAttribute getPiece_Width();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Piece#getRectangle <em>Rectangle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rectangle</em>'.
	 * @see RootElement.Piece#getRectangle()
	 * @see #getPiece()
	 * @generated
	 */
	EAttribute getPiece_Rectangle();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Piece#getHeight <em>Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Height</em>'.
	 * @see RootElement.Piece#getHeight()
	 * @see #getPiece()
	 * @generated
	 */
	EAttribute getPiece_Height();

	/**
	 * Returns the meta object for class '{@link RootElement.GamePanel <em>Game Panel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game Panel</em>'.
	 * @see RootElement.GamePanel
	 * @generated
	 */
	EClass getGamePanel();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see RootElement.GamePanel#getTime()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_Time();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#getBasketX <em>Basket X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Basket X</em>'.
	 * @see RootElement.GamePanel#getBasketX()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_BasketX();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#isReverse <em>Reverse</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Reverse</em>'.
	 * @see RootElement.GamePanel#isReverse()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_Reverse();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#getStart <em>Start</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start</em>'.
	 * @see RootElement.GamePanel#getStart()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_Start();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#getEnd <em>End</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End</em>'.
	 * @see RootElement.GamePanel#getEnd()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_End();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#getPauseStart <em>Pause Start</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pause Start</em>'.
	 * @see RootElement.GamePanel#getPauseStart()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_PauseStart();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.GamePanel#getTemp <em>Temp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Temp</em>'.
	 * @see RootElement.GamePanel#getTemp()
	 * @see #getGamePanel()
	 * @generated
	 */
	EAttribute getGamePanel_Temp();

	/**
	 * Returns the meta object for the reference '{@link RootElement.GamePanel#getBasket <em>Basket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Basket</em>'.
	 * @see RootElement.GamePanel#getBasket()
	 * @see #getGamePanel()
	 * @generated
	 */
	EReference getGamePanel_Basket();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see RootElement.GamePanel#Constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getGamePanel__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Constraint2(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint2</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint2</em>' operation.
	 * @see RootElement.GamePanel#Constraint2(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getGamePanel__Constraint2__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Constraint3(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint3</em>' operation.
	 * @see RootElement.GamePanel#Constraint3(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getGamePanel__Constraint3__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Gamepanel(int) <em>Gamepanel</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Gamepanel</em>' operation.
	 * @see RootElement.GamePanel#Gamepanel(int)
	 * @generated
	 */
	EOperation getGamePanel__Gamepanel__int();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#PauseGame() <em>Pause Game</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Pause Game</em>' operation.
	 * @see RootElement.GamePanel#PauseGame()
	 * @generated
	 */
	EOperation getGamePanel__PauseGame();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#ResumeGame() <em>Resume Game</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Resume Game</em>' operation.
	 * @see RootElement.GamePanel#ResumeGame()
	 * @generated
	 */
	EOperation getGamePanel__ResumeGame();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#PaintComponent() <em>Paint Component</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Paint Component</em>' operation.
	 * @see RootElement.GamePanel#PaintComponent()
	 * @generated
	 */
	EOperation getGamePanel__PaintComponent();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Operation5() <em>Operation5</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Operation5</em>' operation.
	 * @see RootElement.GamePanel#Operation5()
	 * @generated
	 */
	EOperation getGamePanel__Operation5();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Operation6() <em>Operation6</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Operation6</em>' operation.
	 * @see RootElement.GamePanel#Operation6()
	 * @generated
	 */
	EOperation getGamePanel__Operation6();

	/**
	 * Returns the meta object for the '{@link RootElement.GamePanel#Operation7() <em>Operation7</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Operation7</em>' operation.
	 * @see RootElement.GamePanel#Operation7()
	 * @generated
	 */
	EOperation getGamePanel__Operation7();

	/**
	 * Returns the meta object for class '{@link RootElement.Ball <em>Ball</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ball</em>'.
	 * @see RootElement.Ball
	 * @generated
	 */
	EClass getBall();

	/**
	 * Returns the meta object for the '{@link RootElement.Ball#Ball(int, int, int, int) <em>Ball</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Ball</em>' operation.
	 * @see RootElement.Ball#Ball(int, int, int, int)
	 * @generated
	 */
	EOperation getBall__Ball__int_int_int_int();

	/**
	 * Returns the meta object for class '{@link RootElement.Main <em>Main</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Main</em>'.
	 * @see RootElement.Main
	 * @generated
	 */
	EClass getMain();

	/**
	 * Returns the meta object for the '{@link RootElement.Main#main() <em>Main</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Main</em>' operation.
	 * @see RootElement.Main#main()
	 * @generated
	 */
	EOperation getMain__Main();

	/**
	 * Returns the meta object for class '{@link RootElement.DashBoard <em>Dash Board</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dash Board</em>'.
	 * @see RootElement.DashBoard
	 * @generated
	 */
	EClass getDashBoard();

	/**
	 * Returns the meta object for the '{@link RootElement.DashBoard#Dashboard() <em>Dashboard</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Dashboard</em>' operation.
	 * @see RootElement.DashBoard#Dashboard()
	 * @generated
	 */
	EOperation getDashBoard__Dashboard();

	/**
	 * Returns the meta object for class '{@link RootElement.Game <em>Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game</em>'.
	 * @see RootElement.Game
	 * @generated
	 */
	EClass getGame();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Game#getScore <em>Score</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Score</em>'.
	 * @see RootElement.Game#getScore()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Score();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Game#getColorIndex <em>Color Index</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Color Index</em>'.
	 * @see RootElement.Game#getColorIndex()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_ColorIndex();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Game#getColors <em>Colors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Colors</em>'.
	 * @see RootElement.Game#getColors()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Colors();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#getInstance(int, int) <em>Get Instance</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Instance</em>' operation.
	 * @see RootElement.Game#getInstance(int, int)
	 * @generated
	 */
	EOperation getGame__GetInstance__int_int();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#getNewInstance(int, int) <em>Get New Instance</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get New Instance</em>' operation.
	 * @see RootElement.Game#getNewInstance(int, int)
	 * @generated
	 */
	EOperation getGame__GetNewInstance__int_int();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#Game(int, int) <em>Game</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Game</em>' operation.
	 * @see RootElement.Game#Game(int, int)
	 * @generated
	 */
	EOperation getGame__Game__int_int();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#getFrame() <em>Get Frame</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Frame</em>' operation.
	 * @see RootElement.Game#getFrame()
	 * @generated
	 */
	EOperation getGame__GetFrame();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#resetScore() <em>Reset Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Reset Score</em>' operation.
	 * @see RootElement.Game#resetScore()
	 * @generated
	 */
	EOperation getGame__ResetScore();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#setScore(boolean) <em>Set Score</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Score</em>' operation.
	 * @see RootElement.Game#setScore(boolean)
	 * @generated
	 */
	EOperation getGame__SetScore__boolean();

	/**
	 * Returns the meta object for the '{@link RootElement.Game#setTime(int) <em>Set Time</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Time</em>' operation.
	 * @see RootElement.Game#setTime(int)
	 * @generated
	 */
	EOperation getGame__SetTime__int();

	/**
	 * Returns the meta object for class '{@link RootElement.GameEnding <em>Game Ending</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game Ending</em>'.
	 * @see RootElement.GameEnding
	 * @generated
	 */
	EClass getGameEnding();

	/**
	 * Returns the meta object for the '{@link RootElement.GameEnding#GameEnding() <em>Game Ending</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Game Ending</em>' operation.
	 * @see RootElement.GameEnding#GameEnding()
	 * @generated
	 */
	EOperation getGameEnding__GameEnding();

	/**
	 * Returns the meta object for class '{@link RootElement.Selection <em>Selection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Selection</em>'.
	 * @see RootElement.Selection
	 * @generated
	 */
	EClass getSelection();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.Selection#getSelected <em>Selected</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Selected</em>'.
	 * @see RootElement.Selection#getSelected()
	 * @see #getSelection()
	 * @generated
	 */
	EAttribute getSelection_Selected();

	/**
	 * Returns the meta object for the '{@link RootElement.Selection#Constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Constraint1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Constraint1</em>' operation.
	 * @see RootElement.Selection#Constraint1(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getSelection__Constraint1__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link RootElement.Selection#Selection() <em>Selection</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Selection</em>' operation.
	 * @see RootElement.Selection#Selection()
	 * @generated
	 */
	EOperation getSelection__Selection();

	/**
	 * Returns the meta object for class '{@link RootElement.persons <em>persons</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>persons</em>'.
	 * @see RootElement.persons
	 * @generated
	 */
	EClass getpersons();

	/**
	 * Returns the meta object for class '{@link RootElement.StateMachine1 <em>State Machine1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State Machine1</em>'.
	 * @see RootElement.StateMachine1
	 * @generated
	 */
	EClass getStateMachine1();

	/**
	 * Returns the meta object for class '{@link RootElement.StateMachine2 <em>State Machine2</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State Machine2</em>'.
	 * @see RootElement.StateMachine2
	 * @generated
	 */
	EClass getStateMachine2();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RootElementFactory getRootElementFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link RootElement.impl.PersonImpl <em>Person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.PersonImpl
		 * @see RootElement.impl.RootElementPackageImpl#getPerson()
		 * @generated
		 */
		EClass PERSON = eINSTANCE.getPerson();

		/**
		 * The meta object literal for the '<em><b>Password</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__PASSWORD = eINSTANCE.getPerson_Password();

		/**
		 * The meta object literal for the '<em><b>Highscore</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__HIGHSCORE = eINSTANCE.getPerson_Highscore();

		/**
		 * The meta object literal for the '<em><b>Logged In</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERSON__LOGGED_IN = eINSTANCE.getPerson_LoggedIn();

		/**
		 * The meta object literal for the '<em><b>Serial Verison UID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__SERIAL_VERISON_UID = eINSTANCE.getPerson_SerialVerisonUID();

		/**
		 * The meta object literal for the '<em><b>Username</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__USERNAME = eINSTANCE.getPerson_Username();

		/**
		 * The meta object literal for the '<em><b>Person</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERSON__PERSON = eINSTANCE.getPerson_Person();

		/**
		 * The meta object literal for the '<em><b>Constraintpass</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___CONSTRAINTPASS__DIAGNOSTICCHAIN_MAP = eINSTANCE.getPerson__Constraintpass__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getPerson__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Constraint2</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___CONSTRAINT2__DIAGNOSTICCHAIN_MAP = eINSTANCE.getPerson__Constraint2__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Constraint3</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___CONSTRAINT3__DIAGNOSTICCHAIN_MAP = eINSTANCE.getPerson__Constraint3__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Register Person</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___REGISTER_PERSON__PERSON = eINSTANCE.getPerson__RegisterPerson__Person();

		/**
		 * The meta object literal for the '<em><b>Confirm Login</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___CONFIRM_LOGIN__PERSON = eINSTANCE.getPerson__ConfirmLogin__Person();

		/**
		 * The meta object literal for the '<em><b>Get Total High Score</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___GET_TOTAL_HIGH_SCORE = eINSTANCE.getPerson__GetTotalHighScore();

		/**
		 * The meta object literal for the '<em><b>Set Total High Score</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___SET_TOTAL_HIGH_SCORE__PERSON_INT = eINSTANCE.getPerson__SetTotalHighScore__Person_int();

		/**
		 * The meta object literal for the '<em><b>Compare To</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___COMPARE_TO__PERSON = eINSTANCE.getPerson__CompareTo__Person();

		/**
		 * The meta object literal for the '<em><b>Read Person</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___READ_PERSON = eINSTANCE.getPerson__ReadPerson();

		/**
		 * The meta object literal for the '<em><b>Write Person</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___WRITE_PERSON__PERSON = eINSTANCE.getPerson__WritePerson__Person();

		/**
		 * The meta object literal for the '<em><b>Person</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PERSON___PERSON__STRING_STRING = eINSTANCE.getPerson__Person__String_String();

		/**
		 * The meta object literal for the '{@link RootElement.impl.basketImpl <em>basket</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.basketImpl
		 * @see RootElement.impl.RootElementPackageImpl#getbasket()
		 * @generated
		 */
		EClass BASKET = eINSTANCE.getbasket();

		/**
		 * The meta object literal for the '<em><b>Game</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASKET__GAME = eINSTANCE.getbasket_Game();

		/**
		 * The meta object literal for the '<em><b>Basket</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BASKET___BASKET__INT_INT_INT_INT = eINSTANCE.getbasket__Basket__int_int_int_int();

		/**
		 * The meta object literal for the '{@link RootElement.impl.PieceImpl <em>Piece</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.PieceImpl
		 * @see RootElement.impl.RootElementPackageImpl#getPiece()
		 * @generated
		 */
		EClass PIECE = eINSTANCE.getPiece();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIECE__X = eINSTANCE.getPiece_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIECE__Y = eINSTANCE.getPiece_Y();

		/**
		 * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIECE__WIDTH = eINSTANCE.getPiece_Width();

		/**
		 * The meta object literal for the '<em><b>Rectangle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIECE__RECTANGLE = eINSTANCE.getPiece_Rectangle();

		/**
		 * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIECE__HEIGHT = eINSTANCE.getPiece_Height();

		/**
		 * The meta object literal for the '{@link RootElement.impl.GamePanelImpl <em>Game Panel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.GamePanelImpl
		 * @see RootElement.impl.RootElementPackageImpl#getGamePanel()
		 * @generated
		 */
		EClass GAME_PANEL = eINSTANCE.getGamePanel();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__TIME = eINSTANCE.getGamePanel_Time();

		/**
		 * The meta object literal for the '<em><b>Basket X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__BASKET_X = eINSTANCE.getGamePanel_BasketX();

		/**
		 * The meta object literal for the '<em><b>Reverse</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__REVERSE = eINSTANCE.getGamePanel_Reverse();

		/**
		 * The meta object literal for the '<em><b>Start</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__START = eINSTANCE.getGamePanel_Start();

		/**
		 * The meta object literal for the '<em><b>End</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__END = eINSTANCE.getGamePanel_End();

		/**
		 * The meta object literal for the '<em><b>Pause Start</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__PAUSE_START = eINSTANCE.getGamePanel_PauseStart();

		/**
		 * The meta object literal for the '<em><b>Temp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_PANEL__TEMP = eINSTANCE.getGamePanel_Temp();

		/**
		 * The meta object literal for the '<em><b>Basket</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME_PANEL__BASKET = eINSTANCE.getGamePanel_Basket();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getGamePanel__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Constraint2</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___CONSTRAINT2__DIAGNOSTICCHAIN_MAP = eINSTANCE.getGamePanel__Constraint2__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Constraint3</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___CONSTRAINT3__DIAGNOSTICCHAIN_MAP = eINSTANCE.getGamePanel__Constraint3__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Gamepanel</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___GAMEPANEL__INT = eINSTANCE.getGamePanel__Gamepanel__int();

		/**
		 * The meta object literal for the '<em><b>Pause Game</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___PAUSE_GAME = eINSTANCE.getGamePanel__PauseGame();

		/**
		 * The meta object literal for the '<em><b>Resume Game</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___RESUME_GAME = eINSTANCE.getGamePanel__ResumeGame();

		/**
		 * The meta object literal for the '<em><b>Paint Component</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___PAINT_COMPONENT = eINSTANCE.getGamePanel__PaintComponent();

		/**
		 * The meta object literal for the '<em><b>Operation5</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___OPERATION5 = eINSTANCE.getGamePanel__Operation5();

		/**
		 * The meta object literal for the '<em><b>Operation6</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___OPERATION6 = eINSTANCE.getGamePanel__Operation6();

		/**
		 * The meta object literal for the '<em><b>Operation7</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_PANEL___OPERATION7 = eINSTANCE.getGamePanel__Operation7();

		/**
		 * The meta object literal for the '{@link RootElement.impl.BallImpl <em>Ball</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.BallImpl
		 * @see RootElement.impl.RootElementPackageImpl#getBall()
		 * @generated
		 */
		EClass BALL = eINSTANCE.getBall();

		/**
		 * The meta object literal for the '<em><b>Ball</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BALL___BALL__INT_INT_INT_INT = eINSTANCE.getBall__Ball__int_int_int_int();

		/**
		 * The meta object literal for the '{@link RootElement.impl.MainImpl <em>Main</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.MainImpl
		 * @see RootElement.impl.RootElementPackageImpl#getMain()
		 * @generated
		 */
		EClass MAIN = eINSTANCE.getMain();

		/**
		 * The meta object literal for the '<em><b>Main</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MAIN___MAIN = eINSTANCE.getMain__Main();

		/**
		 * The meta object literal for the '{@link RootElement.impl.DashBoardImpl <em>Dash Board</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.DashBoardImpl
		 * @see RootElement.impl.RootElementPackageImpl#getDashBoard()
		 * @generated
		 */
		EClass DASH_BOARD = eINSTANCE.getDashBoard();

		/**
		 * The meta object literal for the '<em><b>Dashboard</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DASH_BOARD___DASHBOARD = eINSTANCE.getDashBoard__Dashboard();

		/**
		 * The meta object literal for the '{@link RootElement.impl.GameImpl <em>Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.GameImpl
		 * @see RootElement.impl.RootElementPackageImpl#getGame()
		 * @generated
		 */
		EClass GAME = eINSTANCE.getGame();

		/**
		 * The meta object literal for the '<em><b>Score</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__SCORE = eINSTANCE.getGame_Score();

		/**
		 * The meta object literal for the '<em><b>Color Index</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__COLOR_INDEX = eINSTANCE.getGame_ColorIndex();

		/**
		 * The meta object literal for the '<em><b>Colors</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__COLORS = eINSTANCE.getGame_Colors();

		/**
		 * The meta object literal for the '<em><b>Get Instance</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___GET_INSTANCE__INT_INT = eINSTANCE.getGame__GetInstance__int_int();

		/**
		 * The meta object literal for the '<em><b>Get New Instance</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___GET_NEW_INSTANCE__INT_INT = eINSTANCE.getGame__GetNewInstance__int_int();

		/**
		 * The meta object literal for the '<em><b>Game</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___GAME__INT_INT = eINSTANCE.getGame__Game__int_int();

		/**
		 * The meta object literal for the '<em><b>Get Frame</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___GET_FRAME = eINSTANCE.getGame__GetFrame();

		/**
		 * The meta object literal for the '<em><b>Reset Score</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___RESET_SCORE = eINSTANCE.getGame__ResetScore();

		/**
		 * The meta object literal for the '<em><b>Set Score</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___SET_SCORE__BOOLEAN = eINSTANCE.getGame__SetScore__boolean();

		/**
		 * The meta object literal for the '<em><b>Set Time</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME___SET_TIME__INT = eINSTANCE.getGame__SetTime__int();

		/**
		 * The meta object literal for the '{@link RootElement.impl.GameEndingImpl <em>Game Ending</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.GameEndingImpl
		 * @see RootElement.impl.RootElementPackageImpl#getGameEnding()
		 * @generated
		 */
		EClass GAME_ENDING = eINSTANCE.getGameEnding();

		/**
		 * The meta object literal for the '<em><b>Game Ending</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation GAME_ENDING___GAME_ENDING = eINSTANCE.getGameEnding__GameEnding();

		/**
		 * The meta object literal for the '{@link RootElement.impl.SelectionImpl <em>Selection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.SelectionImpl
		 * @see RootElement.impl.RootElementPackageImpl#getSelection()
		 * @generated
		 */
		EClass SELECTION = eINSTANCE.getSelection();

		/**
		 * The meta object literal for the '<em><b>Selected</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SELECTION__SELECTED = eINSTANCE.getSelection_Selected();

		/**
		 * The meta object literal for the '<em><b>Constraint1</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELECTION___CONSTRAINT1__DIAGNOSTICCHAIN_MAP = eINSTANCE.getSelection__Constraint1__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Selection</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELECTION___SELECTION = eINSTANCE.getSelection__Selection();

		/**
		 * The meta object literal for the '{@link RootElement.impl.personsImpl <em>persons</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.personsImpl
		 * @see RootElement.impl.RootElementPackageImpl#getpersons()
		 * @generated
		 */
		EClass PERSONS = eINSTANCE.getpersons();

		/**
		 * The meta object literal for the '{@link RootElement.impl.StateMachine1Impl <em>State Machine1</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.StateMachine1Impl
		 * @see RootElement.impl.RootElementPackageImpl#getStateMachine1()
		 * @generated
		 */
		EClass STATE_MACHINE1 = eINSTANCE.getStateMachine1();

		/**
		 * The meta object literal for the '{@link RootElement.impl.StateMachine2Impl <em>State Machine2</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.impl.StateMachine2Impl
		 * @see RootElement.impl.RootElementPackageImpl#getStateMachine2()
		 * @generated
		 */
		EClass STATE_MACHINE2 = eINSTANCE.getStateMachine2();

	}

} //RootElementPackage
