/**
 */
package RootElement;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>basket</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RootElement.basket#getGame <em>Game</em>}</li>
 * </ul>
 *
 * @see RootElement.RootElementPackage#getbasket()
 * @model
 * @generated
 */
public interface basket extends Piece {
	/**
	 * Returns the value of the '<em><b>Game</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Game</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Game</em>' reference.
	 * @see #setGame(GamePanel)
	 * @see RootElement.RootElementPackage#getbasket_Game()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	GamePanel getGame();

	/**
	 * Sets the value of the '{@link RootElement.basket#getGame <em>Game</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Game</em>' reference.
	 * @see #getGame()
	 * @generated
	 */
	void setGame(GamePanel value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model xRequired="true" xOrdered="false" yRequired="true" yOrdered="false" widthRequired="true" widthOrdered="false" heightRequired="true" heightOrdered="false"
	 * @generated
	 */
	void Basket(int x, int y, int width, int height);

} // basket
