/**
 */
package RootElement;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Game Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RootElement.GamePanel#getTime <em>Time</em>}</li>
 *   <li>{@link RootElement.GamePanel#getBasketX <em>Basket X</em>}</li>
 *   <li>{@link RootElement.GamePanel#isReverse <em>Reverse</em>}</li>
 *   <li>{@link RootElement.GamePanel#getStart <em>Start</em>}</li>
 *   <li>{@link RootElement.GamePanel#getEnd <em>End</em>}</li>
 *   <li>{@link RootElement.GamePanel#getPauseStart <em>Pause Start</em>}</li>
 *   <li>{@link RootElement.GamePanel#getTemp <em>Temp</em>}</li>
 *   <li>{@link RootElement.GamePanel#getBasket <em>Basket</em>}</li>
 * </ul>
 *
 * @see RootElement.RootElementPackage#getGamePanel()
 * @model
 * @generated
 */
public interface GamePanel extends EObject {
	/**
	 * Returns the value of the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' attribute.
	 * @see #setTime(int)
	 * @see RootElement.RootElementPackage#getGamePanel_Time()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getTime();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getTime <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' attribute.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(int value);

	/**
	 * Returns the value of the '<em><b>Basket X</b></em>' attribute.
	 * The default value is <code>"-10"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Basket X</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basket X</em>' attribute.
	 * @see #setBasketX(int)
	 * @see RootElement.RootElementPackage#getGamePanel_BasketX()
	 * @model default="-10" required="true" ordered="false"
	 * @generated
	 */
	int getBasketX();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getBasketX <em>Basket X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Basket X</em>' attribute.
	 * @see #getBasketX()
	 * @generated
	 */
	void setBasketX(int value);

	/**
	 * Returns the value of the '<em><b>Reverse</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reverse</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reverse</em>' attribute.
	 * @see #setReverse(boolean)
	 * @see RootElement.RootElementPackage#getGamePanel_Reverse()
	 * @model default="false" required="true" ordered="false"
	 * @generated
	 */
	boolean isReverse();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#isReverse <em>Reverse</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reverse</em>' attribute.
	 * @see #isReverse()
	 * @generated
	 */
	void setReverse(boolean value);

	/**
	 * Returns the value of the '<em><b>Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start</em>' attribute.
	 * @see #setStart(long)
	 * @see RootElement.RootElementPackage#getGamePanel_Start()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	long getStart();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getStart <em>Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start</em>' attribute.
	 * @see #getStart()
	 * @generated
	 */
	void setStart(long value);

	/**
	 * Returns the value of the '<em><b>End</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End</em>' attribute.
	 * @see #setEnd(long)
	 * @see RootElement.RootElementPackage#getGamePanel_End()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	long getEnd();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getEnd <em>End</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End</em>' attribute.
	 * @see #getEnd()
	 * @generated
	 */
	void setEnd(long value);

	/**
	 * Returns the value of the '<em><b>Pause Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pause Start</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pause Start</em>' attribute.
	 * @see #setPauseStart(long)
	 * @see RootElement.RootElementPackage#getGamePanel_PauseStart()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	long getPauseStart();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getPauseStart <em>Pause Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pause Start</em>' attribute.
	 * @see #getPauseStart()
	 * @generated
	 */
	void setPauseStart(long value);

	/**
	 * Returns the value of the '<em><b>Temp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Temp</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temp</em>' attribute.
	 * @see #setTemp(int)
	 * @see RootElement.RootElementPackage#getGamePanel_Temp()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getTemp();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getTemp <em>Temp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temp</em>' attribute.
	 * @see #getTemp()
	 * @generated
	 */
	void setTemp(int value);

	/**
	 * Returns the value of the '<em><b>Basket</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Basket</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basket</em>' reference.
	 * @see #setBasket(basket)
	 * @see RootElement.RootElementPackage#getGamePanel_Basket()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	basket getBasket();

	/**
	 * Sets the value of the '{@link RootElement.GamePanel#getBasket <em>Basket</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Basket</em>' reference.
	 * @see #getBasket()
	 * @generated
	 */
	void setBasket(basket value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * {{OCL}self.time > 0 & self.time<120}
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * {{OCL}self.reverse=false
	 * }
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraint2(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * {{OCL} self.basketX=-10}
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraint3(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model newTimeRequired="true" newTimeOrdered="false"
	 * @generated
	 */
	void Gamepanel(int newTime);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void PauseGame();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void ResumeGame();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void PaintComponent();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Operation5();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Operation6();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Operation7();

} // GamePanel
