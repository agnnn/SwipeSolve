/**
 */
package RootElement;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ball</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RootElement.RootElementPackage#getBall()
 * @model
 * @generated
 */
public interface Ball extends Piece {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model xRequired="true" xOrdered="false" yRequired="true" yOrdered="false" widthRequired="true" widthOrdered="false" heightRequired="true" heightOrdered="false"
	 * @generated
	 */
	void Ball(int x, int y, int width, int height);

} // Ball
