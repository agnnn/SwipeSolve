/**
 */
package RootElement.impl;

import RootElement.GamePanel;
import RootElement.RootElementPackage;
import RootElement.basket;

import RootElement.util.RootElementValidator;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Game Panel</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link RootElement.impl.GamePanelImpl#getTime <em>Time</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#getBasketX <em>Basket X</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#isReverse <em>Reverse</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#getStart <em>Start</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#getEnd <em>End</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#getPauseStart <em>Pause Start</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#getTemp <em>Temp</em>}</li>
 *   <li>{@link RootElement.impl.GamePanelImpl#getBasket <em>Basket</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GamePanelImpl extends MinimalEObjectImpl.Container implements GamePanel {
	/**
	 * The default value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected static final int TIME_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected int time = TIME_EDEFAULT;

	/**
	 * The default value of the '{@link #getBasketX() <em>Basket X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBasketX()
	 * @generated
	 * @ordered
	 */
	protected static final int BASKET_X_EDEFAULT = -10;

	/**
	 * The cached value of the '{@link #getBasketX() <em>Basket X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBasketX()
	 * @generated
	 * @ordered
	 */
	protected int basketX = BASKET_X_EDEFAULT;

	/**
	 * The default value of the '{@link #isReverse() <em>Reverse</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isReverse()
	 * @generated
	 * @ordered
	 */
	protected static final boolean REVERSE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isReverse() <em>Reverse</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isReverse()
	 * @generated
	 * @ordered
	 */
	protected boolean reverse = REVERSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getStart() <em>Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart()
	 * @generated
	 * @ordered
	 */
	protected static final long START_EDEFAULT = 0L;

	/**
	 * The cached value of the '{@link #getStart() <em>Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart()
	 * @generated
	 * @ordered
	 */
	protected long start = START_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnd() <em>End</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnd()
	 * @generated
	 * @ordered
	 */
	protected static final long END_EDEFAULT = 0L;

	/**
	 * The cached value of the '{@link #getEnd() <em>End</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnd()
	 * @generated
	 * @ordered
	 */
	protected long end = END_EDEFAULT;

	/**
	 * The default value of the '{@link #getPauseStart() <em>Pause Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPauseStart()
	 * @generated
	 * @ordered
	 */
	protected static final long PAUSE_START_EDEFAULT = 0L;

	/**
	 * The cached value of the '{@link #getPauseStart() <em>Pause Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPauseStart()
	 * @generated
	 * @ordered
	 */
	protected long pauseStart = PAUSE_START_EDEFAULT;

	/**
	 * The default value of the '{@link #getTemp() <em>Temp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemp()
	 * @generated
	 * @ordered
	 */
	protected static final int TEMP_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTemp() <em>Temp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemp()
	 * @generated
	 * @ordered
	 */
	protected int temp = TEMP_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBasket() <em>Basket</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBasket()
	 * @generated
	 * @ordered
	 */
	protected basket basket;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GamePanelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootElementPackage.Literals.GAME_PANEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTime() {
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(int newTime) {
		int oldTime = time;
		time = newTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__TIME, oldTime, time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getBasketX() {
		return basketX;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBasketX(int newBasketX) {
		int oldBasketX = basketX;
		basketX = newBasketX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__BASKET_X, oldBasketX, basketX));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isReverse() {
		return reverse;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReverse(boolean newReverse) {
		boolean oldReverse = reverse;
		reverse = newReverse;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__REVERSE, oldReverse, reverse));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public long getStart() {
		return start;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStart(long newStart) {
		long oldStart = start;
		start = newStart;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__START, oldStart, start));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public long getEnd() {
		return end;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnd(long newEnd) {
		long oldEnd = end;
		end = newEnd;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__END, oldEnd, end));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public long getPauseStart() {
		return pauseStart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPauseStart(long newPauseStart) {
		long oldPauseStart = pauseStart;
		pauseStart = newPauseStart;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__PAUSE_START, oldPauseStart, pauseStart));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTemp() {
		return temp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTemp(int newTemp) {
		int oldTemp = temp;
		temp = newTemp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__TEMP, oldTemp, temp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public basket getBasket() {
		if (basket != null && basket.eIsProxy()) {
			InternalEObject oldBasket = (InternalEObject)basket;
			basket = (basket)eResolveProxy(oldBasket);
			if (basket != oldBasket) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RootElementPackage.GAME_PANEL__BASKET, oldBasket, basket));
			}
		}
		return basket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public basket basicGetBasket() {
		return basket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBasket(basket newBasket) {
		basket oldBasket = basket;
		basket = newBasket;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME_PANEL__BASKET, oldBasket, basket));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.GAME_PANEL__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraint2(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.GAME_PANEL__CONSTRAINT2,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraint2", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraint3(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.GAME_PANEL__CONSTRAINT3,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraint3", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Gamepanel(int newTime) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void PauseGame() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void ResumeGame() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void PaintComponent() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Operation5() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Operation6() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Operation7() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RootElementPackage.GAME_PANEL__TIME:
				return getTime();
			case RootElementPackage.GAME_PANEL__BASKET_X:
				return getBasketX();
			case RootElementPackage.GAME_PANEL__REVERSE:
				return isReverse();
			case RootElementPackage.GAME_PANEL__START:
				return getStart();
			case RootElementPackage.GAME_PANEL__END:
				return getEnd();
			case RootElementPackage.GAME_PANEL__PAUSE_START:
				return getPauseStart();
			case RootElementPackage.GAME_PANEL__TEMP:
				return getTemp();
			case RootElementPackage.GAME_PANEL__BASKET:
				if (resolve) return getBasket();
				return basicGetBasket();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RootElementPackage.GAME_PANEL__TIME:
				setTime((Integer)newValue);
				return;
			case RootElementPackage.GAME_PANEL__BASKET_X:
				setBasketX((Integer)newValue);
				return;
			case RootElementPackage.GAME_PANEL__REVERSE:
				setReverse((Boolean)newValue);
				return;
			case RootElementPackage.GAME_PANEL__START:
				setStart((Long)newValue);
				return;
			case RootElementPackage.GAME_PANEL__END:
				setEnd((Long)newValue);
				return;
			case RootElementPackage.GAME_PANEL__PAUSE_START:
				setPauseStart((Long)newValue);
				return;
			case RootElementPackage.GAME_PANEL__TEMP:
				setTemp((Integer)newValue);
				return;
			case RootElementPackage.GAME_PANEL__BASKET:
				setBasket((basket)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case RootElementPackage.GAME_PANEL__TIME:
				setTime(TIME_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__BASKET_X:
				setBasketX(BASKET_X_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__REVERSE:
				setReverse(REVERSE_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__START:
				setStart(START_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__END:
				setEnd(END_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__PAUSE_START:
				setPauseStart(PAUSE_START_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__TEMP:
				setTemp(TEMP_EDEFAULT);
				return;
			case RootElementPackage.GAME_PANEL__BASKET:
				setBasket((basket)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RootElementPackage.GAME_PANEL__TIME:
				return time != TIME_EDEFAULT;
			case RootElementPackage.GAME_PANEL__BASKET_X:
				return basketX != BASKET_X_EDEFAULT;
			case RootElementPackage.GAME_PANEL__REVERSE:
				return reverse != REVERSE_EDEFAULT;
			case RootElementPackage.GAME_PANEL__START:
				return start != START_EDEFAULT;
			case RootElementPackage.GAME_PANEL__END:
				return end != END_EDEFAULT;
			case RootElementPackage.GAME_PANEL__PAUSE_START:
				return pauseStart != PAUSE_START_EDEFAULT;
			case RootElementPackage.GAME_PANEL__TEMP:
				return temp != TEMP_EDEFAULT;
			case RootElementPackage.GAME_PANEL__BASKET:
				return basket != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case RootElementPackage.GAME_PANEL___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return Constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.GAME_PANEL___CONSTRAINT2__DIAGNOSTICCHAIN_MAP:
				return Constraint2((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.GAME_PANEL___CONSTRAINT3__DIAGNOSTICCHAIN_MAP:
				return Constraint3((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.GAME_PANEL___GAMEPANEL__INT:
				Gamepanel((Integer)arguments.get(0));
				return null;
			case RootElementPackage.GAME_PANEL___PAUSE_GAME:
				PauseGame();
				return null;
			case RootElementPackage.GAME_PANEL___RESUME_GAME:
				ResumeGame();
				return null;
			case RootElementPackage.GAME_PANEL___PAINT_COMPONENT:
				PaintComponent();
				return null;
			case RootElementPackage.GAME_PANEL___OPERATION5:
				Operation5();
				return null;
			case RootElementPackage.GAME_PANEL___OPERATION6:
				Operation6();
				return null;
			case RootElementPackage.GAME_PANEL___OPERATION7:
				Operation7();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (time: ");
		result.append(time);
		result.append(", basketX: ");
		result.append(basketX);
		result.append(", reverse: ");
		result.append(reverse);
		result.append(", start: ");
		result.append(start);
		result.append(", end: ");
		result.append(end);
		result.append(", pauseStart: ");
		result.append(pauseStart);
		result.append(", temp: ");
		result.append(temp);
		result.append(')');
		return result.toString();
	}

} //GamePanelImpl
