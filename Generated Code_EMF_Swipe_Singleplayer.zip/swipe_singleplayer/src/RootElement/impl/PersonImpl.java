/**
 */
package RootElement.impl;

import RootElement.Person;
import RootElement.RootElementPackage;

import RootElement.util.RootElementValidator;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link RootElement.impl.PersonImpl#getPassword <em>Password</em>}</li>
 *   <li>{@link RootElement.impl.PersonImpl#getHighscore <em>Highscore</em>}</li>
 *   <li>{@link RootElement.impl.PersonImpl#getLoggedIn <em>Logged In</em>}</li>
 *   <li>{@link RootElement.impl.PersonImpl#getSerialVerisonUID <em>Serial Verison UID</em>}</li>
 *   <li>{@link RootElement.impl.PersonImpl#getUsername <em>Username</em>}</li>
 *   <li>{@link RootElement.impl.PersonImpl#getPerson <em>Person</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PersonImpl extends MinimalEObjectImpl.Container implements Person {
	/**
	 * The default value of the '{@link #getPassword() <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword()
	 * @generated
	 * @ordered
	 */
	protected static final String PASSWORD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPassword() <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassword()
	 * @generated
	 * @ordered
	 */
	protected String password = PASSWORD_EDEFAULT;

	/**
	 * The default value of the '{@link #getHighscore() <em>Highscore</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHighscore()
	 * @generated
	 * @ordered
	 */
	protected static final int HIGHSCORE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getHighscore() <em>Highscore</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHighscore()
	 * @generated
	 * @ordered
	 */
	protected int highscore = HIGHSCORE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLoggedIn() <em>Logged In</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoggedIn()
	 * @generated
	 * @ordered
	 */
	protected Person loggedIn;

	/**
	 * The default value of the '{@link #getSerialVerisonUID() <em>Serial Verison UID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSerialVerisonUID()
	 * @generated
	 * @ordered
	 */
	protected static final long SERIAL_VERISON_UID_EDEFAULT = 0L;

	/**
	 * The cached value of the '{@link #getSerialVerisonUID() <em>Serial Verison UID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSerialVerisonUID()
	 * @generated
	 * @ordered
	 */
	protected long serialVerisonUID = SERIAL_VERISON_UID_EDEFAULT;

	/**
	 * The default value of the '{@link #getUsername() <em>Username</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsername()
	 * @generated
	 * @ordered
	 */
	protected static final String USERNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUsername() <em>Username</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsername()
	 * @generated
	 * @ordered
	 */
	protected String username = USERNAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPerson() <em>Person</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerson()
	 * @generated
	 * @ordered
	 */
	protected Person person;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PersonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootElementPackage.Literals.PERSON;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPassword(String newPassword) {
		String oldPassword = password;
		password = newPassword;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.PERSON__PASSWORD, oldPassword, password));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getHighscore() {
		return highscore;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHighscore(int newHighscore) {
		int oldHighscore = highscore;
		highscore = newHighscore;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.PERSON__HIGHSCORE, oldHighscore, highscore));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Person getLoggedIn() {
		if (loggedIn != null && loggedIn.eIsProxy()) {
			InternalEObject oldLoggedIn = (InternalEObject)loggedIn;
			loggedIn = (Person)eResolveProxy(oldLoggedIn);
			if (loggedIn != oldLoggedIn) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RootElementPackage.PERSON__LOGGED_IN, oldLoggedIn, loggedIn));
			}
		}
		return loggedIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Person basicGetLoggedIn() {
		return loggedIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLoggedIn(Person newLoggedIn) {
		Person oldLoggedIn = loggedIn;
		loggedIn = newLoggedIn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.PERSON__LOGGED_IN, oldLoggedIn, loggedIn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public long getSerialVerisonUID() {
		return serialVerisonUID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSerialVerisonUID(long newSerialVerisonUID) {
		long oldSerialVerisonUID = serialVerisonUID;
		serialVerisonUID = newSerialVerisonUID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.PERSON__SERIAL_VERISON_UID, oldSerialVerisonUID, serialVerisonUID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUsername(String newUsername) {
		String oldUsername = username;
		username = newUsername;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.PERSON__USERNAME, oldUsername, username));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Person getPerson() {
		if (person != null && person.eIsProxy()) {
			InternalEObject oldPerson = (InternalEObject)person;
			person = (Person)eResolveProxy(oldPerson);
			if (person != oldPerson) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RootElementPackage.PERSON__PERSON, oldPerson, person));
			}
		}
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Person basicGetPerson() {
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPerson(Person newPerson) {
		Person oldPerson = person;
		person = newPerson;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.PERSON__PERSON, oldPerson, person));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraintpass(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.PERSON__CONSTRAINTPASS,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraintpass", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraint1(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.PERSON__CONSTRAINT1,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraint1", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraint2(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.PERSON__CONSTRAINT2,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraint2", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Constraint3(DiagnosticChain diagnostics, Map<Object, Object> context) {
		// TODO: implement this method
		// -> specify the condition that violates the invariant
		// -> verify the details of the diagnostic, including severity and message
		// Ensure that you remove @generated or mark it @generated NOT
		if (false) {
			if (diagnostics != null) {
				diagnostics.add
					(new BasicDiagnostic
						(Diagnostic.ERROR,
						 RootElementValidator.DIAGNOSTIC_SOURCE,
						 RootElementValidator.PERSON__CONSTRAINT3,
						 EcorePlugin.INSTANCE.getString("_UI_GenericInvariant_diagnostic", new Object[] { "Constraint3", EObjectValidator.getObjectLabel(this, context) }),
						 new Object [] { this }));
			}
			return false;
		}
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerPerson(Person person) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void confirmLogin(Person person) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void getTotalHighScore() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalHighScore(Person person, int highscore) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void compareTo(Person person) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void readPerson() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void writePerson(Person person) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Person(String username, String password) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RootElementPackage.PERSON__PASSWORD:
				return getPassword();
			case RootElementPackage.PERSON__HIGHSCORE:
				return getHighscore();
			case RootElementPackage.PERSON__LOGGED_IN:
				if (resolve) return getLoggedIn();
				return basicGetLoggedIn();
			case RootElementPackage.PERSON__SERIAL_VERISON_UID:
				return getSerialVerisonUID();
			case RootElementPackage.PERSON__USERNAME:
				return getUsername();
			case RootElementPackage.PERSON__PERSON:
				if (resolve) return getPerson();
				return basicGetPerson();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RootElementPackage.PERSON__PASSWORD:
				setPassword((String)newValue);
				return;
			case RootElementPackage.PERSON__HIGHSCORE:
				setHighscore((Integer)newValue);
				return;
			case RootElementPackage.PERSON__LOGGED_IN:
				setLoggedIn((Person)newValue);
				return;
			case RootElementPackage.PERSON__SERIAL_VERISON_UID:
				setSerialVerisonUID((Long)newValue);
				return;
			case RootElementPackage.PERSON__USERNAME:
				setUsername((String)newValue);
				return;
			case RootElementPackage.PERSON__PERSON:
				setPerson((Person)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case RootElementPackage.PERSON__PASSWORD:
				setPassword(PASSWORD_EDEFAULT);
				return;
			case RootElementPackage.PERSON__HIGHSCORE:
				setHighscore(HIGHSCORE_EDEFAULT);
				return;
			case RootElementPackage.PERSON__LOGGED_IN:
				setLoggedIn((Person)null);
				return;
			case RootElementPackage.PERSON__SERIAL_VERISON_UID:
				setSerialVerisonUID(SERIAL_VERISON_UID_EDEFAULT);
				return;
			case RootElementPackage.PERSON__USERNAME:
				setUsername(USERNAME_EDEFAULT);
				return;
			case RootElementPackage.PERSON__PERSON:
				setPerson((Person)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RootElementPackage.PERSON__PASSWORD:
				return PASSWORD_EDEFAULT == null ? password != null : !PASSWORD_EDEFAULT.equals(password);
			case RootElementPackage.PERSON__HIGHSCORE:
				return highscore != HIGHSCORE_EDEFAULT;
			case RootElementPackage.PERSON__LOGGED_IN:
				return loggedIn != null;
			case RootElementPackage.PERSON__SERIAL_VERISON_UID:
				return serialVerisonUID != SERIAL_VERISON_UID_EDEFAULT;
			case RootElementPackage.PERSON__USERNAME:
				return USERNAME_EDEFAULT == null ? username != null : !USERNAME_EDEFAULT.equals(username);
			case RootElementPackage.PERSON__PERSON:
				return person != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case RootElementPackage.PERSON___CONSTRAINTPASS__DIAGNOSTICCHAIN_MAP:
				return Constraintpass((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.PERSON___CONSTRAINT1__DIAGNOSTICCHAIN_MAP:
				return Constraint1((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.PERSON___CONSTRAINT2__DIAGNOSTICCHAIN_MAP:
				return Constraint2((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.PERSON___CONSTRAINT3__DIAGNOSTICCHAIN_MAP:
				return Constraint3((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case RootElementPackage.PERSON___REGISTER_PERSON__PERSON:
				registerPerson((Person)arguments.get(0));
				return null;
			case RootElementPackage.PERSON___CONFIRM_LOGIN__PERSON:
				confirmLogin((Person)arguments.get(0));
				return null;
			case RootElementPackage.PERSON___GET_TOTAL_HIGH_SCORE:
				getTotalHighScore();
				return null;
			case RootElementPackage.PERSON___SET_TOTAL_HIGH_SCORE__PERSON_INT:
				setTotalHighScore((Person)arguments.get(0), (Integer)arguments.get(1));
				return null;
			case RootElementPackage.PERSON___COMPARE_TO__PERSON:
				compareTo((Person)arguments.get(0));
				return null;
			case RootElementPackage.PERSON___READ_PERSON:
				readPerson();
				return null;
			case RootElementPackage.PERSON___WRITE_PERSON__PERSON:
				writePerson((Person)arguments.get(0));
				return null;
			case RootElementPackage.PERSON___PERSON__STRING_STRING:
				Person((String)arguments.get(0), (String)arguments.get(1));
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (password: ");
		result.append(password);
		result.append(", highscore: ");
		result.append(highscore);
		result.append(", serialVerisonUID: ");
		result.append(serialVerisonUID);
		result.append(", username: ");
		result.append(username);
		result.append(')');
		return result.toString();
	}

} //PersonImpl
