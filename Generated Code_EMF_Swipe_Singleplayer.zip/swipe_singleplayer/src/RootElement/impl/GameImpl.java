/**
 */
package RootElement.impl;

import RootElement.Game;
import RootElement.RootElementPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link RootElement.impl.GameImpl#getScore <em>Score</em>}</li>
 *   <li>{@link RootElement.impl.GameImpl#getColorIndex <em>Color Index</em>}</li>
 *   <li>{@link RootElement.impl.GameImpl#getColors <em>Colors</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GameImpl extends MinimalEObjectImpl.Container implements Game {
	/**
	 * The default value of the '{@link #getScore() <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScore()
	 * @generated
	 * @ordered
	 */
	protected static final int SCORE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getScore() <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScore()
	 * @generated
	 * @ordered
	 */
	protected int score = SCORE_EDEFAULT;

	/**
	 * The default value of the '{@link #getColorIndex() <em>Color Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColorIndex()
	 * @generated
	 * @ordered
	 */
	protected static final int COLOR_INDEX_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getColorIndex() <em>Color Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColorIndex()
	 * @generated
	 * @ordered
	 */
	protected int colorIndex = COLOR_INDEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getColors() <em>Colors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColors()
	 * @generated
	 * @ordered
	 */
	protected static final String COLORS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getColors() <em>Colors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColors()
	 * @generated
	 * @ordered
	 */
	protected String colors = COLORS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GameImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootElementPackage.Literals.GAME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getScore() {
		return score;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScore(int newScore) {
		int oldScore = score;
		score = newScore;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME__SCORE, oldScore, score));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getColorIndex() {
		return colorIndex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setColorIndex(int newColorIndex) {
		int oldColorIndex = colorIndex;
		colorIndex = newColorIndex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME__COLOR_INDEX, oldColorIndex, colorIndex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getColors() {
		return colors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setColors(String newColors) {
		String oldColors = colors;
		colors = newColors;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RootElementPackage.GAME__COLORS, oldColors, colors));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void getInstance(int time, int custom) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void getNewInstance(int time, int custom) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Game(int time, int custom) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void getFrame() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void resetScore() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScore(boolean increase) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(int time) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RootElementPackage.GAME__SCORE:
				return getScore();
			case RootElementPackage.GAME__COLOR_INDEX:
				return getColorIndex();
			case RootElementPackage.GAME__COLORS:
				return getColors();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RootElementPackage.GAME__SCORE:
				setScore((Integer)newValue);
				return;
			case RootElementPackage.GAME__COLOR_INDEX:
				setColorIndex((Integer)newValue);
				return;
			case RootElementPackage.GAME__COLORS:
				setColors((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case RootElementPackage.GAME__SCORE:
				setScore(SCORE_EDEFAULT);
				return;
			case RootElementPackage.GAME__COLOR_INDEX:
				setColorIndex(COLOR_INDEX_EDEFAULT);
				return;
			case RootElementPackage.GAME__COLORS:
				setColors(COLORS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RootElementPackage.GAME__SCORE:
				return score != SCORE_EDEFAULT;
			case RootElementPackage.GAME__COLOR_INDEX:
				return colorIndex != COLOR_INDEX_EDEFAULT;
			case RootElementPackage.GAME__COLORS:
				return COLORS_EDEFAULT == null ? colors != null : !COLORS_EDEFAULT.equals(colors);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case RootElementPackage.GAME___GET_INSTANCE__INT_INT:
				getInstance((Integer)arguments.get(0), (Integer)arguments.get(1));
				return null;
			case RootElementPackage.GAME___GET_NEW_INSTANCE__INT_INT:
				getNewInstance((Integer)arguments.get(0), (Integer)arguments.get(1));
				return null;
			case RootElementPackage.GAME___GAME__INT_INT:
				Game((Integer)arguments.get(0), (Integer)arguments.get(1));
				return null;
			case RootElementPackage.GAME___GET_FRAME:
				getFrame();
				return null;
			case RootElementPackage.GAME___RESET_SCORE:
				resetScore();
				return null;
			case RootElementPackage.GAME___SET_SCORE__BOOLEAN:
				setScore((Boolean)arguments.get(0));
				return null;
			case RootElementPackage.GAME___SET_TIME__INT:
				setTime((Integer)arguments.get(0));
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (score: ");
		result.append(score);
		result.append(", colorIndex: ");
		result.append(colorIndex);
		result.append(", colors: ");
		result.append(colors);
		result.append(')');
		return result.toString();
	}

} //GameImpl
