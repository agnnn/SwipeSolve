package userInterface;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import object.Ball;
import object.Basket;
import object.Person;

public class GamePanel extends JPanel implements KeyListener{

	/*
	 * Attributes
	 */
	private static final long serialVersionUID = -309672691045042209L;
	private int time;
	private int basketX = -10;
	private Thread thread;
	private boolean reverse = false;
	private ArrayList<Ball> balls;
	private long start, end, pauseStart; // time.
	private int temp;
	private Basket basket;
	private boolean pause = false;
	
	/**
	 * GamePanel to create object.
	 */
	public GamePanel(int newTime){
		
		this.time = newTime;
		balls = new ArrayList<Ball>();
		start = System.currentTimeMillis();
		time *= 1000;
		basket = new Basket(basketX, 490, 100, 83);
		
		// setting panel values.
		setBounds(0, 0, 600, 600);
		setOpaque(false);
		setLayout(null);
		setFocusable(true);
		requestFocusInWindow();
		addKeyListener(this);
		
		thread = new Thread(){
			
			@Override
			public void run(){
				
				while(true){
					
					while(pause){
						try {
							Thread.sleep(200);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					
					try {
						Thread.sleep(20);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					if(reverse && basketX <= -10)
						reverse = false;
					else if(!reverse && basketX >= 500)
						reverse = true;
					
					if(reverse)
						basketX -= 4;
					else
						basketX += 4;
					
					basket.setX(basketX);
					repaint();
					
					end = System.currentTimeMillis();
					if(end - start >= time)
						break;
					
					Game.setTime((int) (time - (end-start))/1000);
					
				}
				
				int score = Game.getScore();
				if(score > Person.getTotalHighScore())
					Person.setTotalHighScore(Person.getLoggedIn(), score);
				Game.resetScore();
				Game.getInstance(0,-1).getFrame().dispose();
				new GameEnding(newTime, score).setVisible(true);
				
			}
			
		};
		thread.start();
		
	}
	
	public void PauseGame(){
		
		if(!pause){
			pause = true;
			pauseStart = System.currentTimeMillis();
		}
	}
	
	public void ResumeGame(){
		
		if(pause){
			pause = false;
			long pauseEnd = System.currentTimeMillis();
			pauseEnd -= pauseStart;
			start += pauseEnd;
		}
	}
	
	protected void paintComponent(Graphics g){
		
		super.paintComponent(g);
		g.fillOval(250, -25, 100, 50);
		
		if(reverse)
			g.drawImage(new ImageIcon("images/reverse.png").getImage(), basketX, 490, 100, 83, null);
		else
			g.drawImage(new ImageIcon("images/basket.png").getImage(), basketX, 490, 100, 83, null);
		
		for(int i = 0; i < balls.size(); i++){
			temp = balls.get(i).getY();
			
			if(temp >= 600){
				
				balls.remove(i);
				Game.setScore(false);
				continue;
			
			}
			
			if(balls.get(i).getRectangle().intersects(basket.getRectangle())){
				
				balls.remove(i);
				Game.setScore(true);
				continue;
				
			}
			
			g.drawImage(new ImageIcon("images/ball.png").getImage(), 280, balls.get(i).getY(), 40, 40, null);
			balls.get(i).setY(temp + 7);
			
		}
		
	}

	@Override
	public void keyPressed(KeyEvent key) {
		
		if(key.getKeyCode() == KeyEvent.VK_ENTER){
			
			balls.add(new Ball(280, -10, 40, 40));
			
		}
		
	}
	@Override
	public void keyReleased(KeyEvent arg0) {}

	@Override
	public void keyTyped(KeyEvent key) {}
	
}
