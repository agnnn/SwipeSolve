package userInterface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import object.Person;

public class GameEnding extends JFrame {

	private static final long serialVersionUID = -5679300761746289928L;
	private JPanel contentPane;
	private JButton restart;
	private JButton exit;
	private JLabel highScore;
	private JLabel yourScore;

	public GameEnding(int time, int score) {
		
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("Help");
		bar.add(menu);
		JMenu logout = new JMenu("Logout");
		bar.add(logout);
		logout.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				GameEnding.this.dispose();
				new Dashboard().setVisible(true);
			}
			
		});
		menu.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "There is a basket moving on the bottom\n"
						+ "When you press the enter, it throw the ball towards bottom side,\n"
						+ "if ball hits basket, you will get +1 if it is miss then you will get"
						+ "-1.", "Help", JOptionPane.INFORMATION_MESSAGE);	
			}
			
		});
		this.setJMenuBar(bar);
		
		setTitle("Swipe Solve");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(275, 180);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		yourScore = new JLabel("Your Score: "+score);
		yourScore.setFont(new Font("Tahoma", Font.PLAIN, 16));
		yourScore.setBounds(10, 11, 239, 32);
		contentPane.add(yourScore);
		
		highScore = new JLabel("High Score: "+Person.getTotalHighScore());
		highScore.setBounds(10, 54, 239, 14);
		contentPane.add(highScore);
		
		exit = new JButton("Exit");
		exit.setBackground(Color.WHITE);
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);
				
			}
		});
		exit.setBounds(10, 90, 80, 23);
		contentPane.add(exit);
		
		restart = new JButton("Restart");
		restart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Game.getNewInstance(time,-1);
				GameEnding.this.dispose();
				
			}
		});
		restart.setBackground(Color.WHITE);
		restart.setBounds(160, 90, 89, 23);
		contentPane.add(restart);
	
	}

}
