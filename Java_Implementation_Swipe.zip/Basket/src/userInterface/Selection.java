package userInterface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Selection extends JFrame {

	/*
	 * Attributes..
	 */
	private static final long serialVersionUID = 1948779740722846906L;
	private JPanel contentPane;
	private JLabel gameTitle;
	private JLabel seconds;
	private JSlider time;
	private JLabel timeLabel;
	private JButton start;
	private int selected = 30;
	private JCheckBox customMap;
	private JLabel map;
	private JComboBox<String> back;
	private String[] colors = {"CYAN", "WHITE", "GREEN", "RED", "YELLOW", "ORANGE", "PINK"};

	/**
	 * To select the time for game.
	 */
	public Selection() {
		
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("Help");
		bar.add(menu);
		JMenu logout = new JMenu("Logout");
		bar.add(logout);
		logout.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				Selection.this.dispose();
				new Dashboard().setVisible(true);
			}
			
		});
		menu.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "There is a basket moving on the bottom\n"
						+ "When you press the enter, it throw the ball towards bottom side,\n"
						+ "if ball hits basket, you will get +1 if it is miss then you will get"
						+ "-1.", "Help", JOptionPane.INFORMATION_MESSAGE);	
			}
			
		});
		this.setJMenuBar(bar);
		
		// frame.
		setTitle("Game");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(484, 266);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		
		// components.
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		timeLabel = new JLabel("Select Time:");
		timeLabel.setBounds(10, 61, 73, 26);
		contentPane.add(timeLabel);
		
		time = new JSlider();
		time.setValue(60);
		time.setMaximum(300);
		time.setMinimum(30);
		time.setBackground(Color.WHITE);
		time.setBounds(93, 61, 281, 26);
		contentPane.add(time);
		
		//slider actions..
		time.addChangeListener(new ChangeListener(){

			@Override
			public void stateChanged(ChangeEvent arg0) {
			
				selected = time.getValue();
				seconds.setText(selected+" Seconds");
				
			}
			
		});
		
		gameTitle = new JLabel("Basket Ball Game");
		gameTitle.setHorizontalAlignment(SwingConstants.CENTER);
		gameTitle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		gameTitle.setBounds(10, 11, 414, 26);
		contentPane.add(gameTitle);
		
		seconds = new JLabel("60 Seconds");
		seconds.setFont(new Font("Verdana", Font.PLAIN, 11));
		seconds.setBounds(378, 61, 90, 26);
		contentPane.add(seconds);
		
		start = new JButton("Start Game");
		start.setBackground(Color.WHITE);
		start.setBounds(10, 161, 448, 33);
		contentPane.add(start);
		
		customMap = new JCheckBox("Create Custom Map");
		customMap.setBackground(Color.WHITE);
		customMap.setBounds(10, 94, 177, 23);
		contentPane.add(customMap);
		customMap.addChangeListener(new ChangeListener(){

			@Override
			public void stateChanged(ChangeEvent arg0) {
			
				if(customMap.isSelected()){
					map.setEnabled(true);
					back.setEnabled(true);
				}else{
					map.setEnabled(false);
					back.setEnabled(false);
				}
				
			}
			
		});
		
		map = new JLabel("Select Map:");
		map.setEnabled(false);
		map.setBounds(10, 124, 78, 26);
		contentPane.add(map);
		
		back = new JComboBox<String>();
		for(int i = 0; i < colors.length; i++)
			back.addItem(colors[i]);
		back.setEnabled(false);
		back.setBounds(93, 127, 141, 20);
		contentPane.add(back);
		
		// Start game listener to start the game.
		start.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				if(customMap.isSelected())
					Game.getInstance(selected, back.getSelectedIndex());
				else
					Game.getInstance(selected, -1);
				Selection.this.dispose();
				
			}
			
		});
		
	}
}
