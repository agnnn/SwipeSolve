package userInterface;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import object.Person;

public class Dashboard extends JFrame {

	private static final long serialVersionUID = 7784618937728287661L;
	private JPanel contentPane;
	private JTextField username;
	private JPasswordField password;
	private JLabel selectLabel;
	private JRadioButton register;
	private JRadioButton login;
	private JLabel line;
	private JLabel userLabel;
	private JLabel passLabel;
	private JButton execute;
	private ButtonGroup bg;

	public Dashboard() {
		
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("Help");
		bar.add(menu);
		menu.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "There is a basket moving on the bottom\n"
						+ "When you press the enter, it throw the ball towards bottom side,\n"
						+ "if ball hits basket, you will get +1 if it is miss then you will get"
						+ "-1.", "Help", JOptionPane.INFORMATION_MESSAGE);	
			}
			
		});
		this.setJMenuBar(bar);
		
		setTitle("Swipe Solve");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(305, 251);
		setLocationRelativeTo(null);
		
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		selectLabel = new JLabel("Select Function:");
		selectLabel.setBounds(10, 11, 93, 14);
		contentPane.add(selectLabel);
		
		register = new JRadioButton("Register");
		register.setBackground(Color.WHITE);
		register.setBounds(109, 7, 93, 23);
		contentPane.add(register);
		
		login = new JRadioButton("Login");
		login.setSelected(true);
		login.setBackground(Color.WHITE);
		login.setBounds(204, 7, 79, 23);
		contentPane.add(login);
		
		bg = new ButtonGroup();
		bg.add(register);
		bg.add(login);
		
		userLabel = new JLabel("Username:");
		userLabel.setBounds(10, 73, 76, 14);
		contentPane.add(userLabel);
		
		username = new JTextField();
		username.setBounds(109, 70, 171, 20);
		contentPane.add(username);
		username.setColumns(10);
		
		passLabel = new JLabel("Password:");
		passLabel.setBounds(10, 104, 86, 14);
		contentPane.add(passLabel);
		
		password = new JPasswordField();
		password.setBounds(109, 101, 171, 20);
		contentPane.add(password);
		
		execute = new JButton("Execute");
		execute.setBackground(Color.WHITE);
		execute.setBounds(186, 132, 93, 29);
		contentPane.add(execute);
		
		line = new JLabel("____________________________");
		line.setHorizontalAlignment(SwingConstants.CENTER);
		line.setBounds(10, 36, 270, 14);
		contentPane.add(line);
		
		execute.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
			
				String user = username.getText();
				String pass = String.valueOf(password.getPassword());
				
				if(user.equals("") || pass.equals("")){
					JOptionPane.showMessageDialog(null, "Both Username and password should not be empty.");
					return;
				}
				
				Person person = new Person(user, pass);
				
				if(register.isSelected()){
					
					Person.registerPerson(person);
					
				}else{
					
					if(Person.confirmLogin(person)){
						// login...
						Person.setLoggedIn(person);
						new Selection().setVisible(true);
						Dashboard.this.dispose();
					}else
						JOptionPane.showMessageDialog(null, "Invalid username or password.");
					
				}
				
			}
			
		});
		
	}
}
