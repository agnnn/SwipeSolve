package userInterface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Game {

	/*
	 * Attributes.
	 */
	private JFrame frame;
	private JPanel contentPane;
	private GamePanel gamePanel;
	private static JLabel scoreLabel;
	private static JLabel remainingLabel;
	private static int score = 0;
	private static Game game;
	private static int colorIndex = 0;
	private Color[] colors = {Color.CYAN, Color.WHITE, Color.GREEN, Color.RED, Color.YELLOW, Color.ORANGE, Color.PINK};
	

	/**
	 * To save system for creating instances more than one.
	 * 
	 * @param time
	 * @return game panel.
	 */
	public static Game getInstance(int time, int custom){
		
		if(game == null)
			game = new Game(time, custom);
		
		return game;
		
	}
	
	public static Game getNewInstance(int time, int custom){
	
		game = new Game(time, custom);
		
		return game;
		
	}
	
	/**
	 * Create object of game.
	 */
	private Game(int time, int custom){
		
		// creating frame.
		frame = new JFrame("Game");
		frame.setSize(600, 620);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setLayout(null);
		frame.setResizable(false);
		
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("Help");
		JMenu pause = new JMenu("Pause");
		JMenu resume = new JMenu("Resume");
		bar.add(menu);
		bar.add(pause);
		bar.add(resume);
		JMenu logout = new JMenu("Logout");
		bar.add(logout);
		logout.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				Game.getInstance(5, -1).getFrame().dispose();
				new Dashboard().setVisible(true);
			}
			
		});
		menu.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "There is a basket moving on the bottom\n"
						+ "When you press the enter, it throw the ball towards bottom side,\n"
						+ "if ball hits basket, you will get +1 if it is miss then you will get"
						+ "-1.", "Help", JOptionPane.INFORMATION_MESSAGE);	
			}
			
		});
		pause.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				gamePanel.PauseGame();
			}
			
		});
		resume.addMouseListener(new MouseAdapter(){

			@Override
			public void mouseClicked(MouseEvent arg0) {
				gamePanel.ResumeGame();
			}
			
		});
		frame.setJMenuBar(bar);
		
		contentPane = new JPanel();
		contentPane.setLayout(null);
		contentPane.setSize(600, 600);
		frame.setContentPane(contentPane);
		if(custom == -1){
			contentPane.setBackground(colors[colorIndex % 7]);
			colorIndex++;
		}else{
			contentPane.setBackground(colors[custom]);
		}
	
		// game panel.
		gamePanel = new GamePanel(time);
		contentPane.add(gamePanel);
	
		// labels.
		scoreLabel = new JLabel("Score: "+score);
		scoreLabel.setBounds(460, 20, 200, 20);
		scoreLabel.setForeground(Color.RED);
		scoreLabel.setFont(new Font("Verdana", Font.BOLD, 20));
		contentPane.add(scoreLabel);
		
		remainingLabel = new JLabel("Time: "+time);
		remainingLabel.setForeground(Color.RED);
		remainingLabel.setFont(new Font("Verdana", Font.BOLD, 20));
		remainingLabel.setBounds(20, 20, 200, 20);
		contentPane.add(remainingLabel);

		// make the frame visible.
		frame.setVisible(true);
		
	}
	
	public JFrame getFrame(){
		
		return frame;
		
	}
	
	public static void resetScore(){
		score = 0;
	}
	
	public static void setScore(boolean increase){
		
		if(increase)
			score++;
		else
			score--;
		
		scoreLabel.setText("Scores: "+score);
		
	}
		
	public static void setTime(int time){
		
		remainingLabel.setText("Time: "+time);
		
	}
	
	public static int getScore(){
		
		return score;
		
	}
	
}
