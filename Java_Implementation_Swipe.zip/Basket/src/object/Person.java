package object;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Person implements Comparable<Person>, Serializable{

	private static final long serialVersionUID = 4143251107268491615L;
	private String username;
	private String password;
	private int highScore = Integer.MIN_VALUE;
	private static Person loggedIn = null;
	
	public Person(String username, String password) {
	
		this.username = username;
		this.password = password;
	
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		
		return username;
		
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		
		this.username = username;
	
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
	
		return password;
	
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
	
		this.password = password;
	
	}
	
	/**
	 * @return the highScore
	 */
	public int getHighScore() {
	
		return highScore;

	}

	/**
	 * @param highScore the highScore to set
	 */
	public void setHighScore(int highScore) {
	
		this.highScore = highScore;
	
	}
	
	/**
	 * @return the loggedIn
	 */
	public static Person getLoggedIn() {
	
		return loggedIn;
	
	}

	/**
	 * @param loggedIn the loggedIn to set
	 */
	public static void setLoggedIn(Person loggedIn) {
	
		Person.loggedIn = loggedIn;
	
	}

	public static void registerPerson(Person person){
		
		ArrayList<Person> persons = Person.readPersons();
		persons.add(person);
		Person.writePersons(persons);
		JOptionPane.showMessageDialog(null, "Registration Successfull.");
		
	}
	
	public static boolean confirmLogin(Person person){
		
		ArrayList<Person> persons = Person.readPersons();
		for(int i = 0; i < persons.size(); i++){
			
			if(persons.get(i).compareTo(person) == 0){
				return true;
			}
			
		}
		
		return false;
		
	}
	
	public static int getTotalHighScore(){
		
		int highScore = Integer.MIN_VALUE;
		
		ArrayList<Person> persons = Person.readPersons();
		for(int i = 0; i < persons.size(); i++){
			
			if(persons.get(i).getHighScore() > highScore){
				highScore = persons.get(i).getHighScore();
			} 
			
		}
		
		return highScore;
		
	}
	
	public static void setTotalHighScore(Person person, int highScore){
		
		ArrayList<Person> persons = Person.readPersons();
		for(int i = 0; i < persons.size(); i++){
			
			if(persons.get(i).compareTo(person) == 0){
				persons.get(i).setHighScore(highScore);
				break;
			} 
			
		}
		Person.writePersons(persons);
		
	}

	@Override
	public int compareTo(Person person) {

		if(person.username.equals(this.username) 
				&& person.password.equals(this.password))
			return 0;
		else
			return -1;
	
	}
	
	@SuppressWarnings("unchecked")
	public static ArrayList<Person> readPersons(){
		
		File file = new File("registry.ser");
		if(!file.exists())
			try {
				file.createNewFile();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(null, "Error in creating file.");
			}
		
		ArrayList<Person> persons = new ArrayList<Person>();
		
		try {
			
			ObjectInputStream stream = 
					new ObjectInputStream(new FileInputStream(file));
		
			persons = (ArrayList<Person>) stream.readObject();
			stream.close();
			
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null ,"File not found..");
		} catch (IOException e) {
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null ,"Error in parsing data.");
		}
		
		return persons;
		
	}
	
	public static void writePersons(ArrayList<Person> persons){
			
		try {
			
			ObjectOutputStream stream = 
					new ObjectOutputStream(new FileOutputStream("registry.ser"));
		
			stream.writeObject(persons);
			stream.flush();
			stream.close();
			
		} catch (FileNotFoundException e) {
			System.out.println("File not found..");
		} catch (IOException e) {
			System.out.println("IO Error detected.");
		}
		
	}
	
}
