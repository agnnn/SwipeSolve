package object;

import java.awt.Rectangle;

public class Piece {

	/*
	 * Attributes.
	 */
	private int x;
	private int y;
	private int width;
	private int height;
	private Rectangle rectangle;
	
	/**
	 * Constructor.
	 * 
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public Piece(int x, int y, int width, int height) {
		
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		rectangle = new Rectangle(x, y, width, height);
	
	}

	/**
	 * @return the x
	 */
	public int getX() {
		
		return x;
	
	}

	/**
	 * @param x the x to set
	 */
	public void setX(int x) {
	
		this.x = x;
		rectangle = new Rectangle(x, y, width, height);
		
	}

	/**
	 * @return the y
	 */
	public int getY() {
	
		return y;
	
	}

	/**
	 * @param y the y to set
	 */
	public void setY(int y) {
	
		this.y = y;
		rectangle = new Rectangle(x, y, width, height);
	
	}

	/**
	 * @return the width
	 */
	public int getWidth() {
	
		return width;
	
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(int width) {
	
		this.width = width;
	
	}

	/**
	 * @return the height
	 */
	public int getHeight() {
	
		return height;
	
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(int height) {
	
		this.height = height;
	
	}
	
	public Rectangle getRectangle(){
		
		return rectangle;
		
	}
	
}
