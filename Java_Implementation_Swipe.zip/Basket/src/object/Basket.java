package object;

public class Basket extends Piece{

	/**
	 * Consctructor to create basket.
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public Basket(int x, int y, int width, int height) {
	
		super(x, y, width, height);
	
	}

}
