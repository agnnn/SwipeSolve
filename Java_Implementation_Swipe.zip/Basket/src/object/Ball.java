package object;

public class Ball extends Piece{

	/**
	 * Constructor to create Ball.
	 * 
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public Ball(int x, int y, int width, int height) {
	
		super(x, y, width, height);
	
	}

}
