/**
 */
package RootElement;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RootElement.Game#getScore <em>Score</em>}</li>
 *   <li>{@link RootElement.Game#getColorIndex <em>Color Index</em>}</li>
 *   <li>{@link RootElement.Game#getColors <em>Colors</em>}</li>
 * </ul>
 *
 * @see RootElement.RootElementPackage#getGame()
 * @model
 * @generated
 */
public interface Game extends EObject {
	/**
	 * Returns the value of the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Score</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Score</em>' attribute.
	 * @see #setScore(int)
	 * @see RootElement.RootElementPackage#getGame_Score()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getScore();

	/**
	 * Sets the value of the '{@link RootElement.Game#getScore <em>Score</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Score</em>' attribute.
	 * @see #getScore()
	 * @generated
	 */
	void setScore(int value);

	/**
	 * Returns the value of the '<em><b>Color Index</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Color Index</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Color Index</em>' attribute.
	 * @see #setColorIndex(int)
	 * @see RootElement.RootElementPackage#getGame_ColorIndex()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getColorIndex();

	/**
	 * Sets the value of the '{@link RootElement.Game#getColorIndex <em>Color Index</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Color Index</em>' attribute.
	 * @see #getColorIndex()
	 * @generated
	 */
	void setColorIndex(int value);

	/**
	 * Returns the value of the '<em><b>Colors</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Colors</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Colors</em>' attribute.
	 * @see #setColors(String)
	 * @see RootElement.RootElementPackage#getGame_Colors()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getColors();

	/**
	 * Sets the value of the '{@link RootElement.Game#getColors <em>Colors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Colors</em>' attribute.
	 * @see #getColors()
	 * @generated
	 */
	void setColors(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model timeRequired="true" timeOrdered="false" customRequired="true" customOrdered="false"
	 * @generated
	 */
	void getInstance(int time, int custom);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model timeRequired="true" timeOrdered="false" customRequired="true" customOrdered="false"
	 * @generated
	 */
	void getNewInstance(int time, int custom);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model timeRequired="true" timeOrdered="false" customRequired="true" customOrdered="false"
	 * @generated
	 */
	void Game(int time, int custom);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getFrame();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void resetScore();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model increaseRequired="true" increaseOrdered="false"
	 * @generated
	 */
	void setScore(boolean increase);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model timeRequired="true" timeOrdered="false"
	 * @generated
	 */
	void setTime(int time);

} // Game
