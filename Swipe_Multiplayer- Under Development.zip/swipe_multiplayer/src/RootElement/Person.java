/**
 */
package RootElement;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RootElement.Person#getPassword <em>Password</em>}</li>
 *   <li>{@link RootElement.Person#getHighscore <em>Highscore</em>}</li>
 *   <li>{@link RootElement.Person#getLoggedIn <em>Logged In</em>}</li>
 *   <li>{@link RootElement.Person#getSerialVerisonUID <em>Serial Verison UID</em>}</li>
 *   <li>{@link RootElement.Person#getUsername <em>Username</em>}</li>
 *   <li>{@link RootElement.Person#getPerson <em>Person</em>}</li>
 * </ul>
 *
 * @see RootElement.RootElementPackage#getPerson()
 * @model
 * @generated
 */
public interface Person extends EObject {
	/**
	 * Returns the value of the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Password</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Password</em>' attribute.
	 * @see #setPassword(String)
	 * @see RootElement.RootElementPackage#getPerson_Password()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getPassword();

	/**
	 * Sets the value of the '{@link RootElement.Person#getPassword <em>Password</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Password</em>' attribute.
	 * @see #getPassword()
	 * @generated
	 */
	void setPassword(String value);

	/**
	 * Returns the value of the '<em><b>Highscore</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Highscore</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Highscore</em>' attribute.
	 * @see #setHighscore(int)
	 * @see RootElement.RootElementPackage#getPerson_Highscore()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	int getHighscore();

	/**
	 * Sets the value of the '{@link RootElement.Person#getHighscore <em>Highscore</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Highscore</em>' attribute.
	 * @see #getHighscore()
	 * @generated
	 */
	void setHighscore(int value);

	/**
	 * Returns the value of the '<em><b>Logged In</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Logged In</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Logged In</em>' reference.
	 * @see #setLoggedIn(Person)
	 * @see RootElement.RootElementPackage#getPerson_LoggedIn()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Person getLoggedIn();

	/**
	 * Sets the value of the '{@link RootElement.Person#getLoggedIn <em>Logged In</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Logged In</em>' reference.
	 * @see #getLoggedIn()
	 * @generated
	 */
	void setLoggedIn(Person value);

	/**
	 * Returns the value of the '<em><b>Serial Verison UID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Serial Verison UID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Serial Verison UID</em>' attribute.
	 * @see #setSerialVerisonUID(long)
	 * @see RootElement.RootElementPackage#getPerson_SerialVerisonUID()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	long getSerialVerisonUID();

	/**
	 * Sets the value of the '{@link RootElement.Person#getSerialVerisonUID <em>Serial Verison UID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Serial Verison UID</em>' attribute.
	 * @see #getSerialVerisonUID()
	 * @generated
	 */
	void setSerialVerisonUID(long value);

	/**
	 * Returns the value of the '<em><b>Username</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Username</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Username</em>' attribute.
	 * @see #setUsername(String)
	 * @see RootElement.RootElementPackage#getPerson_Username()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	String getUsername();

	/**
	 * Sets the value of the '{@link RootElement.Person#getUsername <em>Username</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Username</em>' attribute.
	 * @see #getUsername()
	 * @generated
	 */
	void setUsername(String value);

	/**
	 * Returns the value of the '<em><b>Person</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Person</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Person</em>' reference.
	 * @see #setPerson(Person)
	 * @see RootElement.RootElementPackage#getPerson_Person()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	Person getPerson();

	/**
	 * Sets the value of the '{@link RootElement.Person#getPerson <em>Person</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Person</em>' reference.
	 * @see #getPerson()
	 * @generated
	 */
	void setPerson(Person value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * {{OCL} self.password.size()>6}
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraintpass(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraint1(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraint2(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * @param diagnostics The chain of diagnostics to which problems are to be appended.
	 * @param context The cache of context-specific information.
	 * <!-- end-model-doc -->
	 * @model
	 * @generated
	 */
	boolean Constraint3(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model personRequired="true" personOrdered="false"
	 * @generated
	 */
	void registerPerson(Person person);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model personRequired="true" personOrdered="false"
	 * @generated
	 */
	void confirmLogin(Person person);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 * @generated
	 */
	void getTotalHighScore();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model personRequired="true" personOrdered="false" highscoreRequired="true" highscoreOrdered="false"
	 * @generated
	 */
	void setTotalHighScore(Person person, int highscore);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model personRequired="true" personOrdered="false"
	 * @generated
	 */
	void compareTo(Person person);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void readPerson();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model personRequired="true" personOrdered="false"
	 * @generated
	 */
	void writePerson(Person person);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model usernameRequired="true" usernameOrdered="false" passwordRequired="true" passwordOrdered="false"
	 * @generated
	 */
	void Person(String username, String password);

} // Person
