/**
 */
package RootElement.impl;

import RootElement.RootElementPackage;
import RootElement.persons;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>persons</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class personsImpl extends MinimalEObjectImpl.Container implements persons {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected personsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootElementPackage.Literals.PERSONS;
	}

} //personsImpl
