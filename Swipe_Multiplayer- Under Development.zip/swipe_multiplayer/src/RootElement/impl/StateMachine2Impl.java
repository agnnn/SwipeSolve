/**
 */
package RootElement.impl;

import RootElement.RootElementPackage;
import RootElement.StateMachine2;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State Machine2</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StateMachine2Impl extends MinimalEObjectImpl.Container implements StateMachine2 {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateMachine2Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootElementPackage.Literals.STATE_MACHINE2;
	}

} //StateMachine2Impl
